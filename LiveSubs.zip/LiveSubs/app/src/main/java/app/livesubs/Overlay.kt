package app.livesubs

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView

/**
 * Bandeau de sous-titres affiché en bas de l'écran, par-dessus n'importe quelle appli.
 * Toutes les méthodes peuvent être appelées depuis n'importe quel thread.
 */
class Overlay(private val context: Context) {
    private val windowManager = context.getSystemService(WindowManager::class.java)
    private val handler = Handler(Looper.getMainLooper())
    private var root: View? = null
    private var label: TextView? = null
    private val hide = Runnable { label?.visibility = View.GONE }

    fun show() {
        handler.post {
            if (root != null) return@post
            val density = context.resources.displayMetrics.density
            fun dp(value: Int) = (value * density + 0.5f).toInt()

            val text = TextView(context).apply {
                setTextColor(Color.WHITE)
                textSize = 17f
                gravity = Gravity.CENTER
                maxLines = 5
                ellipsize = TextUtils.TruncateAt.END
                setBackgroundResource(R.drawable.caption_bg)
                setPadding(dp(12), dp(6), dp(12), dp(6))
                visibility = View.GONE
            }
            val container = FrameLayout(context).apply {
                setPadding(dp(16), 0, dp(16), 0)
                addView(text, FrameLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT, Gravity.CENTER_HORIZONTAL))
            }
            val params = WindowManager.LayoutParams(
                MATCH_PARENT,
                WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT,
            ).apply {
                gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
                y = dp(72)
                // Depuis Android 12, une fenêtre flottante opaque à plus de 80 % bloque les
                // appuis destinés à l'appli située dessous. On reste donc à 80 %.
                alpha = 0.8f
            }
            try {
                windowManager.addView(container, params)
                root = container
                label = text
            } catch (t: Throwable) {
                Log.e("LiveSubs", "Impossible d'afficher la fenêtre flottante", t)
            }
        }
    }

    /** Affiche [text] puis le masque après [durationMs] millisecondes. */
    fun setText(text: String, durationMs: Long) {
        handler.post {
            val view = label ?: return@post
            view.text = text
            view.visibility = View.VISIBLE
            handler.removeCallbacks(hide)
            handler.postDelayed(hide, durationMs)
        }
    }

    fun remove() {
        handler.post {
            handler.removeCallbacks(hide)
            root?.let { runCatching { windowManager.removeView(it) } }
            root = null
            label = null
        }
    }
}
