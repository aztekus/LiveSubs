package app.livesubs

import com.k2fsa.sherpa.onnx.FeatureConfig
import com.k2fsa.sherpa.onnx.OfflineModelConfig
import com.k2fsa.sherpa.onnx.OfflineRecognizer
import com.k2fsa.sherpa.onnx.OfflineRecognizerConfig
import com.k2fsa.sherpa.onnx.OfflineWhisperModelConfig
import com.k2fsa.sherpa.onnx.SileroVadModelConfig
import com.k2fsa.sherpa.onnx.Vad
import com.k2fsa.sherpa.onnx.VadModelConfig
import java.util.Locale

/** Un sous-titre reconnu : le texte et le code de la langue détectée ("en", "ja"…). */
data class Caption(val text: String, val lang: String)

/**
 * Cœur du traitement, sans dépendance Android :
 *  - [feed] découpe le flux audio en passages parlés (Silero VAD) ;
 *  - [transcribe] transforme un passage en texte et détecte sa langue (Whisper).
 *
 * [feed] et [transcribe] utilisent des objets natifs distincts : chacun peut avoir son
 * propre thread, à condition de ne pas appeler une même méthode depuis deux threads.
 */
class SpeechEngine(
    vadModel: String,
    encoder: String,
    decoder: String,
    tokens: String,
    threads: Int,
    maxSegmentSeconds: Int = 12,
    tailPaddings: Int = DEFAULT_TAIL_PADDINGS,
) {
    companion object {
        const val SAMPLE_RATE = 16_000

        /** Nombre d'échantillons à fournir à chaque appel de [feed]. */
        const val WINDOW = 512

        /**
         * Silence ajouté par Whisper après chaque passage, en trames de 10 ms.
         * Moins il y en a, plus le décodage est rapide ; trop peu, et la fin des phrases est coupée.
         */
        const val DEFAULT_TAIL_PADDINGS = 1000

        /** Les sons de moins d'une demi-seconde sont ignorés. */
        private const val MIN_SEGMENT_SAMPLES = SAMPLE_RATE / 2
    }

    private val maxSegmentWindows = maxSegmentSeconds * SAMPLE_RATE / WINDOW
    private var speechWindows = 0

    private val vad = Vad(
        config = VadModelConfig(
            sileroVadModelConfig = SileroVadModelConfig(
                model = vadModel,
                threshold = 0.5f,
                minSilenceDuration = 0.3f,
                minSpeechDuration = 0.25f,
                windowSize = WINDOW,
                maxSpeechDuration = 6f, // au-delà, le VAD coupe à la moindre micro-pause
            ),
            sampleRate = SAMPLE_RATE,
            numThreads = 1,
            provider = "cpu",
        )
    )

    private val recognizer = OfflineRecognizer(
        config = OfflineRecognizerConfig(
            featConfig = FeatureConfig(sampleRate = SAMPLE_RATE, featureDim = 80),
            modelConfig = OfflineModelConfig(
                whisper = OfflineWhisperModelConfig(
                    encoder = encoder,
                    decoder = decoder,
                    language = "", // vide = détection automatique de la langue
                    task = "transcribe",
                    tailPaddings = tailPaddings,
                ),
                tokens = tokens,
                numThreads = threads,
                provider = "cpu",
                modelType = "whisper",
            ),
        )
    )

    /**
     * Reçoit exactement [WINDOW] échantillons (mono, 16 kHz, entre -1 et 1) et appelle
     * [onSegment] pour chaque passage parlé terminé.
     */
    fun feed(window: FloatArray, onSegment: (FloatArray) -> Unit) {
        vad.acceptWaveform(window)

        if (vad.isSpeechDetected()) {
            // Parole ininterrompue : on force une coupe pour ne pas attendre indéfiniment.
            if (++speechWindows >= maxSegmentWindows) {
                vad.flush()
                speechWindows = 0
            }
        } else {
            speechWindows = 0
        }

        while (!vad.empty()) {
            val samples = vad.front().samples
            vad.pop()
            if (samples.size >= MIN_SEGMENT_SAMPLES) onSegment(samples)
        }
    }

    /** Transcrit un passage. Renvoie null s'il ne contient rien d'utile (musique, bruit…). */
    fun transcribe(segment: FloatArray): Caption? {
        val stream = recognizer.createStream()
        val result = try {
            stream.acceptWaveform(segment, SAMPLE_RATE)
            recognizer.decode(stream)
            recognizer.getResult(stream)
        } finally {
            stream.release()
        }
        val text = cleanCaption(result.text)
        if (text.isEmpty()) return null
        val lang = result.lang.lowercase(Locale.ROOT).filter { it in 'a'..'z' }
        return Caption(text, lang)
    }

    /** Libère la mémoire native. Ne plus appeler [feed] ni [transcribe] ensuite. */
    fun release() {
        runCatching { vad.release() }
        runCatching { recognizer.release() }
    }
}
