package app.livesubs

import android.content.Context

/** Réglages mémorisés entre deux lancements. */
object Prefs {
    private fun prefs(context: Context) = context.getSharedPreferences("prefs", Context.MODE_PRIVATE)

    /** Code de la langue de traduction ("fr", "en"…), ou "" pour afficher la langue d'origine. */
    fun target(context: Context): String =
        prefs(context).getString("target", null) ?: Translate.defaultTarget()

    fun setTarget(context: Context, code: String) =
        prefs(context).edit().putString("target", code).apply()

    fun model(context: Context): String =
        prefs(context).getString("model", null) ?: Models.DEFAULT_ID

    fun setModel(context: Context, id: String) =
        prefs(context).edit().putString("model", id).apply()

    fun askedNotifications(context: Context): Boolean =
        prefs(context).getBoolean("askedNotifications", false)

    fun setAskedNotifications(context: Context) =
        prefs(context).edit().putBoolean("askedNotifications", true).apply()
}
