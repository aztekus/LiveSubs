package app.livesubs

import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.io.FilterInputStream
import java.io.InputStream

/** Compte les octets lus sur le réseau, pour afficher une progression. */
private class CountingInputStream(input: InputStream) : FilterInputStream(input) {
    @Volatile
    var count = 0L
        private set

    override fun read(): Int {
        val r = super.read()
        if (r >= 0) count++
        return r
    }

    override fun read(b: ByteArray, off: Int, len: Int): Int {
        val r = super.read(b, off, len)
        if (r > 0) count += r
        return r
    }
}

object TarExtract {

    /**
     * Lit une archive .tar.bz2 au fil du téléchargement et n'écrit sur le disque que les
     * fichiers utiles. S'arrête dès que [expected] fichiers ont été extraits, ce qui évite
     * de télécharger la fin de l'archive quand elle ne sert pas.
     *
     * @param wanted reçoit le nom d'un fichier de l'archive (sans son dossier) et renvoie
     *               le nom sous lequel l'enregistrer, ou null pour l'ignorer
     * @return les noms des fichiers écrits dans [destDir]
     */
    fun extract(
        source: InputStream,
        totalBytes: Long,
        destDir: File,
        expected: Int,
        wanted: (String) -> String?,
        onProgress: (Int) -> Unit,
    ): Set<String> {
        val counting = CountingInputStream(source)
        val written = HashSet<String>()
        val buffer = ByteArray(1 shl 16)
        var lastPercent = -1

        fun report() {
            if (totalBytes <= 0) return
            val percent = (counting.count * 100 / totalBytes).toInt().coerceIn(0, 100)
            if (percent != lastPercent) {
                lastPercent = percent
                onProgress(percent)
            }
        }

        TarArchiveInputStream(
            BZip2CompressorInputStream(BufferedInputStream(counting, 1 shl 16))
        ).use { tar ->
            while (written.size < expected) {
                val entry = tar.nextTarEntry ?: break
                val outName = if (entry.isDirectory) null else wanted(entry.name.substringAfterLast('/'))
                if (outName == null) {
                    // Fichier inutile : on le parcourt sans l'écrire (la progression continue).
                    while (tar.read(buffer) >= 0) report()
                    continue
                }
                FileOutputStream(File(destDir, outName)).use { out ->
                    while (true) {
                        val n = tar.read(buffer)
                        if (n < 0) break
                        out.write(buffer, 0, n)
                        report()
                    }
                }
                written += outName
            }
        }
        return written
    }
}
