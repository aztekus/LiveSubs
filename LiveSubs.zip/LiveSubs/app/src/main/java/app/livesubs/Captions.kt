package app.livesubs

import java.util.Locale

// Petites fonctions sans dépendance Android (faciles à tester sur un PC).

/** Annotations que Whisper ajoute parfois sur de la musique ou du bruit : [Music], (applause), ♪… */
private val ANNOTATIONS = Regex("""\[[^\]]*]|\([^)]*\)|（[^）]*）|【[^】]*】|[♪♫]+""")
private val SPACES = Regex("""\s+""")

/** Nettoie le texte brut de Whisper ; renvoie "" s'il ne reste rien d'utile à afficher. */
fun cleanCaption(raw: String): String {
    val text = raw.replace(ANNOTATIONS, " ").replace(SPACES, " ").trim()
    return if (text.any { it.isLetterOrDigit() }) text else ""
}

/** Nom lisible d'une langue ("en" → "anglais") dans la langue du téléphone. */
fun languageName(code: String, capitalize: Boolean = false): String {
    val locale = Locale.getDefault()
    val tag = if (code == "jw") "jv" else code // Whisper note le javanais "jw"
    val name = Locale.forLanguageTag(tag).getDisplayLanguage(locale).ifEmpty { code }
    return if (capitalize) name.replaceFirstChar { it.titlecase(locale) } else name
}

/** Durée d'affichage d'un sous-titre, selon sa longueur (entre 3 et 9 secondes). */
fun displayMillis(text: String): Long = (2000L + text.length * 70L).coerceIn(3000L, 9000L)
