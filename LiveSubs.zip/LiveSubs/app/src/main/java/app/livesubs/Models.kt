package app.livesubs

import android.content.Context
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

/** Un modèle Whisper multilingue proposé dans l'appli. */
data class WhisperModel(val id: String, val labelRes: Int, val archive: String)

object Models {
    // Modèles Whisper convertis en ONNX, publiés par le projet sherpa-onnx.
    private const val BASE_URL = "https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models/"
    private const val VAD_URL = BASE_URL + "silero_vad.onnx"

    // Du plus léger au plus précis. Tous sont multilingues (une centaine de langues).
    val ALL = listOf(
        WhisperModel("base", R.string.model_base, "sherpa-onnx-whisper-base.tar.bz2"),
        WhisperModel("small", R.string.model_small, "sherpa-onnx-whisper-small.tar.bz2"),
        WhisperModel("turbo", R.string.model_turbo, "sherpa-onnx-whisper-turbo.tar.bz2"),
        WhisperModel("large-v3", R.string.model_large, "sherpa-onnx-whisper-large-v3.tar.bz2"),
    )
    const val DEFAULT_ID = "turbo"

    fun byId(id: String): WhisperModel = ALL.firstOrNull { it.id == id } ?: ALL.first { it.id == DEFAULT_ID }

    private fun root(context: Context) = File(context.filesDir, "models")
    private fun dir(context: Context, model: WhisperModel) = File(root(context), "whisper-${model.id}")
    private fun marker(context: Context, model: WhisperModel) = File(dir(context, model), ".ok")

    fun vad(context: Context) = File(root(context), "silero_vad.onnx")
    fun encoder(context: Context, model: WhisperModel) = File(dir(context, model), "encoder.onnx")
    fun decoder(context: Context, model: WhisperModel) = File(dir(context, model), "decoder.onnx")
    fun tokens(context: Context, model: WhisperModel) = File(dir(context, model), "tokens.txt")

    fun isReady(context: Context, model: WhisperModel): Boolean =
        vad(context).length() > 0 && marker(context, model).exists()

    /** Télécharge le détecteur de voix et le modèle Whisper. Bloquant : à appeler hors du thread principal. */
    @Throws(IOException::class)
    fun download(context: Context, model: WhisperModel, onProgress: (Int) -> Unit) {
        root(context).mkdirs()

        // 1) Détecteur de voix (moins de 1 Mo)
        val vad = vad(context)
        if (vad.length() == 0L) {
            val part = File(root(context), "silero_vad.onnx.part")
            val connection = open(VAD_URL)
            try {
                connection.inputStream.use { input ->
                    FileOutputStream(part).use { output -> input.copyTo(output) }
                }
            } finally {
                connection.disconnect()
            }
            if (!part.renameTo(vad)) throw IOException("Écriture impossible : ${vad.name}")
        }

        // 2) Whisper : on ne garde que les versions compactes (int8) de l'archive
        val dest = dir(context, model)
        dest.deleteRecursively()
        if (!dest.mkdirs()) throw IOException("Création du dossier impossible")
        val connection = open(BASE_URL + model.archive)
        try {
            val written = connection.inputStream.use { input ->
                TarExtract.extract(input, connection.contentLengthLong, dest, 3, ::outputName, onProgress)
            }
            if (written.size != 3) throw IOException("Archive incomplète")
        } finally {
            connection.disconnect()
        }
        marker(context, model).writeText("ok")
    }

    private fun outputName(name: String): String? = when {
        name.endsWith("-encoder.int8.onnx") -> "encoder.onnx"
        name.endsWith("-decoder.int8.onnx") -> "decoder.onnx"
        name.endsWith("-tokens.txt") -> "tokens.txt"
        else -> null
    }

    private fun open(url: String): HttpURLConnection {
        val connection = URL(url).openConnection() as HttpURLConnection
        connection.connectTimeout = 20_000
        connection.readTimeout = 30_000
        connection.instanceFollowRedirects = true
        val code = connection.responseCode
        if (code !in 200..299) {
            connection.disconnect()
            throw IOException("HTTP $code")
        }
        return connection
    }
}

/** État du téléchargement en cours. Vit au niveau du processus pour survivre à une rotation d'écran. */
object ModelStore {
    @Volatile
    var downloading = false
        private set

    @Volatile
    var percent = 0
        private set

    @Volatile
    var error: String? = null
        private set

    /** Appelé (depuis un thread d'arrière-plan) à chaque changement d'état. */
    @Volatile
    var onChanged: (() -> Unit)? = null

    fun start(context: Context, model: WhisperModel) {
        if (downloading) return
        downloading = true
        percent = 0
        error = null
        val appContext = context.applicationContext
        thread(name = "livesubs-download") {
            try {
                Models.download(appContext, model) { p ->
                    percent = p
                    onChanged?.invoke()
                }
            } catch (t: Throwable) {
                error = t.message ?: t.javaClass.simpleName
            } finally {
                downloading = false
                onChanged?.invoke()
            }
        }
    }

    fun clearError() {
        error = null
    }
}
