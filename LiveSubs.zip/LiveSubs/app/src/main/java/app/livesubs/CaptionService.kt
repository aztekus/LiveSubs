package app.livesubs

import android.annotation.SuppressLint
import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import java.util.concurrent.LinkedBlockingDeque
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

/**
 * Service de premier plan qui tourne tant que l'appli est sur ON :
 *
 *   son du téléphone → détection de voix (Silero VAD) → Whisper (texte + langue)
 *                    → traduction (ML Kit) → bandeau de sous-titres + notification
 */
class CaptionService : Service() {

    companion object {
        const val ACTION_START = "app.livesubs.action.START"
        const val ACTION_STOP = "app.livesubs.action.STOP"
        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_RESULT_DATA = "resultData"

        private const val TAG = "LiveSubs"
        private const val CHANNEL_ID = "captions"
        private const val NOTIFICATION_ID = 1

        private const val SAMPLE_RATE = SpeechEngine.SAMPLE_RATE
        private const val WINDOW = SpeechEngine.WINDOW
        private const val MAX_QUEUED_SEGMENTS = 2

        // Alerte « modèle trop lent » : 4 passages d'au moins 2 s décodés moins vite qu'ils ne durent.
        private const val SLOW_MIN_AUDIO_MS = 2000L
        private const val SLOW_STREAK = 4

        /** Vrai tant que le service tourne (lu par l'écran principal). */
        @Volatile
        var isRunning = false
            private set

        /** Code de la dernière langue détectée ("en", "ja"…), ou null. */
        @Volatile
        var detectedLang: String? = null
            private set

        /** Prévenu à chaque changement d'état, éventuellement depuis un thread d'arrière-plan. */
        @Volatile
        var onStateChanged: (() -> Unit)? = null
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private val queue = LinkedBlockingDeque<FloatArray>()
    private lateinit var overlay: Overlay

    @Volatile
    private var active = false

    @Volatile
    private var recorder: AudioRecord? = null
    private var projection: MediaProjection? = null
    private var hub: TranslatorHub? = null

    private val projectionCallback = object : MediaProjection.Callback() {
        // L'utilisateur (ou le système) a mis fin à la capture.
        override fun onStop() = stopSelf()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        overlay = Overlay(this)
        val channel = NotificationChannel(
            CHANNEL_ID,
            getString(R.string.notif_channel),
            NotificationManager.IMPORTANCE_LOW,
        )
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action != ACTION_START) {
            // ACTION_STOP (bouton « Arrêter » de la notification) ou redémarrage sans autorisation.
            stopSelf()
            return START_NOT_STICKY
        }

        // Android exige la notification avant tout accès à la capture.
        try {
            startForeground(
                NOTIFICATION_ID,
                buildNotification(),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION,
            )
        } catch (t: Throwable) {
            Log.e(TAG, "startForeground refusé", t)
            stopSelf()
            return START_NOT_STICKY
        }
        if (active) return START_NOT_STICKY

        val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
        val resultData: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra(EXTRA_RESULT_DATA)
        }
        val mediaProjection = try {
            resultData?.let {
                getSystemService(MediaProjectionManager::class.java).getMediaProjection(resultCode, it)
            }
        } catch (t: Throwable) {
            Log.e(TAG, "getMediaProjection", t)
            null
        }
        if (mediaProjection == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        mediaProjection.registerCallback(projectionCallback, mainHandler)
        projection = mediaProjection
        startPipeline(mediaProjection)
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        active = false
        isRunning = false
        detectedLang = null
        runCatching { recorder?.stop() } // débloque le thread audio
        projection?.let {
            runCatching { it.unregisterCallback(projectionCallback) }
            runCatching { it.stop() }
        }
        projection = null
        overlay.remove()
        hub?.close()
        hub = null
        onStateChanged?.invoke()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ pipeline

    private fun startPipeline(mediaProjection: MediaProjection) {
        active = true
        isRunning = true
        detectedLang = null
        onStateChanged?.invoke()

        overlay.show()
        overlay.setText(getString(R.string.overlay_loading), 120_000)

        val model = Models.byId(Prefs.model(this))
        val target = Prefs.target(this)
        if (target.isNotEmpty()) {
            // Prépare tout de suite le pack de la langue cible (ML Kit pivote par l'anglais).
            hub = TranslatorHub(target).also { it.prepare("en") }
        }

        thread(name = "livesubs-asr") { runPipeline(mediaProjection, model) }
    }

    private fun runPipeline(mediaProjection: MediaProjection, model: WhisperModel) {
        var engine: SpeechEngine? = null
        var audioThread: Thread? = null
        try {
            engine = SpeechEngine(
                vadModel = Models.vad(this).absolutePath,
                encoder = Models.encoder(this, model).absolutePath,
                decoder = Models.decoder(this, model).absolutePath,
                tokens = Models.tokens(this, model).absolutePath,
                threads = Runtime.getRuntime().availableProcessors().coerceIn(2, 4),
            )
            if (!active) return

            val audioRecord = createRecorder(mediaProjection)
            recorder = audioRecord
            audioRecord.startRecording()
            val speech = engine
            audioThread = thread(name = "livesubs-audio") { audioLoop(audioRecord, speech) }

            overlay.setText(getString(R.string.overlay_ready), 3000)
            recognizeLoop(engine)
        } catch (t: Throwable) {
            Log.e(TAG, "Arrêt sur erreur", t)
            App.record(this, t, "service")
            if (active) {
                val reason = t.message ?: t.javaClass.simpleName
                overlay.setText(getString(R.string.overlay_error, reason), 6000)
                mainHandler.postDelayed({ stopSelf() }, 6000)
            }
        } finally {
            active = false
            runCatching { recorder?.stop() }
            runCatching { audioThread?.join(3000) }
            runCatching { recorder?.release() }
            recorder = null
            engine?.release()
        }
    }

    /** Capte le son joué par les autres applis (médias, jeux), en mono 16 kHz. */
    @SuppressLint("MissingPermission") // RECORD_AUDIO est vérifiée par MainActivity avant le démarrage
    private fun createRecorder(mediaProjection: MediaProjection): AudioRecord {
        val capture = AudioPlaybackCaptureConfiguration.Builder(mediaProjection)
            .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
            .addMatchingUsage(AudioAttributes.USAGE_GAME)
            .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
            .build()
        val format = AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(SAMPLE_RATE)
            .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
            .build()
        val minBuffer = AudioRecord.getMinBufferSize(
            SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
        )
        val audioRecord = AudioRecord.Builder()
            .setAudioFormat(format)
            .setBufferSizeInBytes(maxOf(minBuffer, SAMPLE_RATE * 2)) // 1 seconde
            .setAudioPlaybackCaptureConfig(capture)
            .build()
        check(audioRecord.state == AudioRecord.STATE_INITIALIZED) { "Capture audio indisponible" }
        return audioRecord
    }

    /** Thread audio : lit le son par blocs de 512 échantillons et isole les passages parlés. */
    private fun audioLoop(audioRecord: AudioRecord, engine: SpeechEngine) {
        val pcm = ShortArray(WINDOW)
        val samples = FloatArray(WINDOW)
        try {
            while (active) {
                var filled = 0
                while (filled < WINDOW) {
                    val read = audioRecord.read(pcm, filled, WINDOW - filled)
                    if (read < 0 || !active) return
                    if (read == 0) Thread.sleep(10) else filled += read
                }
                for (i in 0 until WINDOW) samples[i] = pcm[i] / 32768f

                engine.feed(samples) { segment ->
                    // Si Whisper prend du retard, on abandonne les plus vieux passages
                    // pour que les sous-titres restent synchronisés avec le son.
                    while (queue.size >= MAX_QUEUED_SEGMENTS) queue.pollFirst()
                    queue.offerLast(segment)
                }
            }
        } catch (t: Throwable) {
            Log.e(TAG, "Thread audio", t)
            App.record(this, t, "audio")
        }
    }

    /** Thread de reconnaissance : transcrit chaque passage, traduit et affiche. */
    private fun recognizeLoop(engine: SpeechEngine) {
        var slowStreak = 0
        var slowWarned = false
        while (active) {
            val segment = queue.pollFirst(300, TimeUnit.MILLISECONDS) ?: continue

            val startedAt = SystemClock.elapsedRealtime()
            val caption = engine.transcribe(segment)
            val decodeMs = SystemClock.elapsedRealtime() - startedAt
            if (!active) break

            // Le modèle suit-il le rythme ? (les passages très courts ne sont pas représentatifs)
            val audioMs = segment.size * 1000L / SAMPLE_RATE
            if (audioMs >= SLOW_MIN_AUDIO_MS) {
                slowStreak = if (decodeMs > audioMs) slowStreak + 1 else 0
            }
            if (caption == null) continue

            val lang = caption.lang
            if (lang.isNotEmpty() && lang != detectedLang) {
                detectedLang = lang
                mainHandler.post { if (active) refreshNotification() }
                onStateChanged?.invoke()
            }

            if (slowStreak >= SLOW_STREAK && !slowWarned) {
                slowWarned = true
                overlay.setText(getString(R.string.overlay_too_slow), 8000)
                continue
            }
            val shown = hub?.translate(caption.text, lang) ?: caption.text
            overlay.setText(shown, displayMillis(shown))
        }
    }

    // ------------------------------------------------------------------ notification

    private fun refreshNotification() {
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, buildNotification())
    }

    private fun buildNotification(): Notification {
        val openApp = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE,
        )
        val stop = PendingIntent.getService(
            this, 1,
            Intent(this, CaptionService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE,
        )
        val lang = detectedLang
        val text = if (lang == null) {
            getString(R.string.notif_waiting)
        } else {
            getString(R.string.notif_lang, languageName(lang))
        }
        val stopAction = Notification.Action.Builder(
            Icon.createWithResource(this, R.drawable.ic_cc),
            getString(R.string.stop),
            stop,
        ).build()

        val builder = Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_cc)
            .setContentTitle(getString(R.string.notif_title))
            .setContentText(text)
            .setContentIntent(openApp)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(stopAction)
        if (Build.VERSION.SDK_INT >= 31) {
            builder.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE)
        }
        return builder.build()
    }
}
