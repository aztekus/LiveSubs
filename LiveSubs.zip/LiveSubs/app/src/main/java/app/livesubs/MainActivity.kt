package app.livesubs

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionConfig
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.WindowManager
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ProgressBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast

/** Seul écran de l'appli : un bouton ON/OFF et deux listes déroulantes. */
class MainActivity : Activity() {

    private companion object {
        const val REQUEST_PERMISSIONS = 1
        const val REQUEST_PROJECTION = 2
    }

    private lateinit var power: Button
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var targetSpinner: Spinner
    private lateinit var modelSpinner: Spinner

    private var resumed = false
    private var waitingForOverlaySetting = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        power = findViewById(R.id.power)
        status = findViewById(R.id.status)
        progress = findViewById(R.id.progress)
        targetSpinner = findViewById(R.id.target)
        modelSpinner = findViewById(R.id.model)

        setUpTargetSpinner()
        setUpModelSpinner()
        App.takeReport(this)?.let { showErrorReport(it) }

        power.setOnClickListener {
            if (CaptionService.isRunning) {
                stopService(Intent(this, CaptionService::class.java))
            } else {
                ModelStore.clearError()
                startFlow()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        resumed = true
        CaptionService.onStateChanged = { runOnUiThread { refresh() } }
        ModelStore.onChanged = { runOnUiThread { onDownloadChanged() } }
        refresh()

        // Retour de l'écran de réglage « Superposition » : on enchaîne si c'est accordé.
        if (waitingForOverlaySetting) {
            waitingForOverlaySetting = false
            if (Settings.canDrawOverlays(this)) startFlow()
        }
    }

    override fun onPause() {
        resumed = false
        CaptionService.onStateChanged = null
        ModelStore.onChanged = null
        super.onPause()
    }

    // ------------------------------------------------------------------ listes déroulantes

    private fun setUpTargetSpinner() {
        val languages = Translate.languages()
        val codes = listOf("") + languages.map { it.first }
        val names = listOf(getString(R.string.no_translation)) + languages.map { it.second }
        targetSpinner.adapter = spinnerAdapter(names)
        targetSpinner.setSelection(codes.indexOf(Prefs.target(this)).coerceAtLeast(0))
        targetSpinner.onItemSelectedListener = onSelected { position ->
            Prefs.setTarget(this, codes[position])
        }
        if (languages.isEmpty()) {
            // Version sans moteur de traduction : le choix de la langue est masqué.
            findViewById<View>(R.id.target_label).visibility = View.GONE
            targetSpinner.visibility = View.GONE
            findViewById<TextView>(R.id.hint).append("\n\n" + getString(R.string.hint_no_translation))
        }
    }

    private fun setUpModelSpinner() {
        val models = Models.ALL
        modelSpinner.adapter = spinnerAdapter(models.map { getString(it.labelRes) })
        modelSpinner.setSelection(models.indexOf(Models.byId(Prefs.model(this))).coerceAtLeast(0))
        modelSpinner.onItemSelectedListener = onSelected { position ->
            Prefs.setModel(this, models[position].id)
        }
    }

    private fun spinnerAdapter(items: List<String>) =
        ArrayAdapter(this, android.R.layout.simple_spinner_item, items).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }

    private fun onSelected(action: (Int) -> Unit) = object : AdapterView.OnItemSelectedListener {
        override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) =
            action(position)

        override fun onNothingSelected(parent: AdapterView<*>?) = Unit
    }

    // ------------------------------------------------------------------ démarrage

    /**
     * Vérifie chaque prérequis dans l'ordre et s'arrête au premier manquant.
     * Rappelée après chaque étape réussie, jusqu'au lancement du service.
     */
    private fun startFlow() {
        if (CaptionService.isRunning || ModelStore.downloading) return

        // 1) Autorisation d'afficher les sous-titres par-dessus les autres applis
        if (!Settings.canDrawOverlays(this)) {
            waitingForOverlaySetting = true
            Toast.makeText(this, R.string.need_overlay, Toast.LENGTH_LONG).show()
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }

        // 2) Capture audio (obligatoire) et notifications (facultatif, demandé une seule fois)
        val missing = ArrayList<String>()
        if (!granted(Manifest.permission.RECORD_AUDIO)) {
            missing += Manifest.permission.RECORD_AUDIO
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            !granted(Manifest.permission.POST_NOTIFICATIONS) &&
            !Prefs.askedNotifications(this)
        ) {
            missing += Manifest.permission.POST_NOTIFICATIONS
        }
        if (missing.isNotEmpty()) {
            requestPermissions(missing.toTypedArray(), REQUEST_PERMISSIONS)
            return
        }

        // 3) Modèle Whisper présent sur le téléphone
        val model = Models.byId(Prefs.model(this))
        if (!Models.isReady(this, model)) {
            ModelStore.start(this, model) // la suite reprend dans onDownloadChanged()
            refresh()
            return
        }

        // 4) Accord d'Android pour capter le son du téléphone
        val manager = getSystemService(MediaProjectionManager::class.java)
        val intent = if (Build.VERSION.SDK_INT >= 34) {
            // Propose directement « tout l'écran » plutôt qu'une seule appli.
            manager.createScreenCaptureIntent(MediaProjectionConfig.createConfigForDefaultDisplay())
        } else {
            manager.createScreenCaptureIntent()
        }
        startActivityForResult(intent, REQUEST_PROJECTION)
    }

    private fun granted(permission: String) =
        checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray,
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != REQUEST_PERMISSIONS) return
        Prefs.setAskedNotifications(this)
        if (granted(Manifest.permission.RECORD_AUDIO)) {
            startFlow()
        } else {
            Toast.makeText(this, R.string.need_audio, Toast.LENGTH_LONG).show()
        }
    }

    private fun onDownloadChanged() {
        refresh()
        val finished = !ModelStore.downloading && ModelStore.error == null
        if (finished && resumed && Models.isReady(this, Models.byId(Prefs.model(this)))) {
            startFlow()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_PROJECTION) return
        if (resultCode != RESULT_OK || data == null) {
            Toast.makeText(this, R.string.projection_denied, Toast.LENGTH_SHORT).show()
            return
        }
        startForegroundService(
            Intent(this, CaptionService::class.java)
                .setAction(CaptionService.ACTION_START)
                .putExtra(CaptionService.EXTRA_RESULT_CODE, resultCode)
                .putExtra(CaptionService.EXTRA_RESULT_DATA, data)
        )
    }

    // ------------------------------------------------------------------ affichage

    /** Montre l'erreur enregistrée lors de la session précédente, avec un bouton pour la copier. */
    private fun showErrorReport(report: String) {
        AlertDialog.Builder(this)
            .setTitle(R.string.error_title)
            .setMessage(report.take(1500))
            .setPositiveButton(R.string.error_copy) { _, _ ->
                getSystemService(ClipboardManager::class.java)
                    .setPrimaryClip(ClipData.newPlainText("LiveSubs", report.take(6000)))
            }
            .setNegativeButton(R.string.close, null)
            .show()
    }

    private fun refresh() {
        val running = CaptionService.isRunning
        val downloading = ModelStore.downloading
        val error = ModelStore.error

        power.isActivated = running
        power.isEnabled = !downloading
        power.setText(if (running) R.string.on else R.string.off)
        targetSpinner.isEnabled = !running && !downloading
        modelSpinner.isEnabled = !running && !downloading

        progress.visibility = if (downloading) View.VISIBLE else View.INVISIBLE
        progress.progress = ModelStore.percent

        val lang = CaptionService.detectedLang
        status.text = when {
            downloading -> getString(R.string.status_downloading, ModelStore.percent)
            running && lang != null -> getString(R.string.status_running_lang, languageName(lang))
            running -> getString(R.string.status_running)
            error != null -> getString(R.string.status_error, error)
            else -> getString(R.string.status_off)
        }

        if (downloading) {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }
}
