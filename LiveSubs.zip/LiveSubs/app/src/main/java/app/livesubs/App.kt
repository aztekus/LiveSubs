package app.livesubs

import android.app.Application
import android.content.Context
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter

/**
 * Garde une trace de la dernière erreur (plantage ou échec du service) dans un fichier,
 * pour l'afficher à l'ouverture suivante : utile pour diagnostiquer sans ordinateur.
 */
class App : Application() {

    override fun onCreate() {
        super.onCreate()
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            record(this, error, thread.name)
            previous?.uncaughtException(thread, error)
        }
    }

    companion object {
        private fun reportFile(context: Context) = File(context.filesDir, "last_error.txt")

        /** Enregistre [error] ; ne lève jamais d'exception. */
        fun record(context: Context, error: Throwable, where: String) {
            runCatching {
                val trace = StringWriter().also { error.printStackTrace(PrintWriter(it)) }
                reportFile(context).writeText("[$where]\n$trace")
            }
        }

        /** Renvoie puis efface le dernier rapport d'erreur, s'il y en a un. */
        fun takeReport(context: Context): String? {
            val file = reportFile(context)
            if (!file.exists()) return null
            val text = runCatching { file.readText() }.getOrNull()
            file.delete()
            return text?.takeIf { it.isNotBlank() }
        }
    }
}
