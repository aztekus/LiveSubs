package app.livesubs

import android.os.SystemClock
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import java.text.Collator
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

// Traduction sur l'appareil avec Google ML Kit. Tout ce qui touche à ML Kit est dans ce fichier.

object Translate {
    /** Langues de traduction disponibles : (code, nom affiché), triées par nom. */
    fun languages(): List<Pair<String, String>> {
        val collator = Collator.getInstance()
        return TranslateLanguage.getAllLanguages()
            .map { it to languageName(it, capitalize = true) }
            .sortedWith { a, b -> collator.compare(a.second, b.second) }
    }

    /** Langue du téléphone si ML Kit la gère, sinon l'anglais. */
    fun defaultTarget(): String =
        TranslateLanguage.fromLanguageTag(Locale.getDefault().language) ?: "en"
}

/**
 * Traduit vers [targetTag] depuis n'importe quelle langue détectée.
 * Les packs de langue (environ 30 Mo chacun) sont téléchargés une seule fois, à la demande ;
 * tant qu'un pack n'est pas prêt, [translate] renvoie null et le texte d'origine est affiché.
 */
class TranslatorHub(targetTag: String) {
    private val target: String? = TranslateLanguage.fromLanguageTag(targetTag)
    private val translators = ConcurrentHashMap<String, Translator>()
    private val ready: MutableSet<String> = ConcurrentHashMap.newKeySet()
    private val pending: MutableSet<String> = ConcurrentHashMap.newKeySet()
    private val lastFailure = ConcurrentHashMap<String, Long>()

    /** Lance en arrière-plan le téléchargement du pack nécessaire pour traduire depuis [sourceTag]. */
    fun prepare(sourceTag: String) {
        val tgt = target ?: return
        val src = TranslateLanguage.fromLanguageTag(sourceTag) ?: return
        if (src == tgt || src in ready) return
        val failedAt = lastFailure[src]
        if (failedAt != null && SystemClock.elapsedRealtime() - failedAt < RETRY_DELAY_MS) return
        if (!pending.add(src)) return

        val translator = translators.getOrPut(src) {
            Translation.getClient(
                TranslatorOptions.Builder()
                    .setSourceLanguage(src)
                    .setTargetLanguage(tgt)
                    .build()
            )
        }
        translator.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .addOnSuccessListener {
                ready.add(src)
                pending.remove(src)
            }
            .addOnFailureListener {
                lastFailure[src] = SystemClock.elapsedRealtime()
                pending.remove(src)
            }
    }

    /**
     * Renvoie la traduction, ou null s'il faut afficher le texte d'origine (même langue,
     * langue non gérée, pack pas encore téléchargé, erreur). Bloquant : hors thread principal.
     */
    fun translate(text: String, sourceTag: String): String? {
        val tgt = target ?: return null
        val src = TranslateLanguage.fromLanguageTag(sourceTag) ?: return null
        if (src == tgt) return null
        if (src !in ready) {
            prepare(sourceTag)
            return null
        }
        val translator = translators[src] ?: return null
        return try {
            Tasks.await(translator.translate(text), 15, TimeUnit.SECONDS)
        } catch (t: Throwable) {
            null
        }
    }

    fun close() {
        translators.values.forEach { runCatching { it.close() } }
        translators.clear()
    }

    private companion object {
        const val RETRY_DELAY_MS = 30_000L
    }
}
