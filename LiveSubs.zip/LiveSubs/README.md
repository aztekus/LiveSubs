# LiveSubs

Sous-titres en direct, traduits, pour tout ce qui sort du haut-parleur du téléphone
(YouTube, navigateur, vidéos…). Tout le traitement se fait sur l'appareil.

- **Écran unique** : bouton ON/OFF, langue de traduction, modèle de sous-titres.
- **Sur ON** : capture du son interne → détection de voix → Whisper (texte + langue détectée)
  → traduction → bandeau en bas de l'écran, par-dessus n'importe quelle appli.
- **Notification** permanente : état, langue détectée, bouton « Arrêter ».

Android 10 minimum.

## Obtenir l'APK sans rien installer (GitHub)

1. Créez un compte sur github.com, puis un dépôt (« New repository »), en cochant « Add a README file ».
2. Dans le dépôt : **Add file → Upload files**, choisissez `LiveSubs.zip`, puis **Commit changes**.
3. **Add file → Create new file**, nommez-le exactement `.github/workflows/build.yml`,
   collez-y le contenu du fichier `build.yml` fourni, puis **Commit changes**.
4. Onglet **Actions** : la compilation démarre (5 à 10 minutes). Quand elle est verte,
   l'APK est dans **Releases** (page d'accueil du dépôt) : `LiveSubs.apk`.
5. Sur le téléphone : ouvrez le fichier et autorisez l'installation depuis cette source.

Si la compilation échoue, ouvrez l'étape en rouge dans l'onglet Actions et copiez le message d'erreur.

## Ou avec Android Studio

Ouvrez le dossier `LiveSubs`, laissez la synchronisation se faire, puis *Build → Build APK(s)*.

## Premier lancement

1. Choisissez la langue et le modèle, appuyez sur le bouton.
2. Accordez : affichage par-dessus les autres applis, enregistrement audio, notifications.
3. Le modèle est téléchargé puis décompressé (une seule fois, plusieurs minutes).
4. Android demande d'autoriser la « capture d'écran » : choisissez tout l'écran. C'est la seule
   façon pour une appli de capter le son interne ; l'image n'est pas utilisée et rien n'est enregistré.
   Android repose cette question à chaque passage sur ON.

## Modèles

| Choix | Modèle | Téléchargement | Remarque |
|---|---|---|---|
| Léger | Whisper base | ≈ 200 Mo | rapide, qualité moyenne hors anglais |
| Équilibré | Whisper small | ≈ 400 Mo | |
| Haute qualité (par défaut) | Whisper large-v3 turbo | ≈ 560 Mo | demande un téléphone haut de gamme |
| Précision maximale | Whisper large-v3 | ≈ 1,1 Go | trop lent pour du direct sur la plupart des téléphones |

Si le modèle choisi ne suit pas le rythme, l'appli l'indique à l'écran : prenez alors le modèle du dessus.

La traduction utilise Google ML Kit (59 langues). Chaque pack de langue (≈ 30 Mo) est téléchargé
à la première utilisation ; ensuite tout fonctionne hors ligne. Tant qu'un pack n'est pas prêt,
le texte s'affiche dans la langue d'origine.

## Limites

- Les applis qui interdisent la capture audio (Netflix, Spotify, appels…) ne sont pas sous-titrées :
  c'est une restriction d'Android.
- Les sous-titres arrivent phrase par phrase, avec un léger décalage.
- Sur de la musique ou du bruit, Whisper peut inventer quelques mots.
- Chaque compilation GitHub signe l'APK avec une clé différente : pour mettre à jour,
  désinstallez l'ancienne version avant d'installer la nouvelle.

## Code

| Fichier | Rôle |
|---|---|
| `MainActivity.kt` | écran, autorisations, lancement |
| `CaptionService.kt` | service d'arrière-plan : capture audio, notification, enchaînement |
| `SpeechEngine.kt` | détection de voix (Silero VAD) + Whisper, via sherpa-onnx |
| `Translate.kt` | traduction ML Kit |
| `Overlay.kt` | bandeau de sous-titres flottant |
| `Models.kt`, `TarExtract.kt` | liste, téléchargement et extraction des modèles |

Composants : sherpa-onnx (Apache 2.0), Whisper (MIT), Silero VAD (MIT),
Apache Commons Compress (Apache 2.0), Google ML Kit (conditions d'utilisation Google).
